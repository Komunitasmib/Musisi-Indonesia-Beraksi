// Firebase client config
