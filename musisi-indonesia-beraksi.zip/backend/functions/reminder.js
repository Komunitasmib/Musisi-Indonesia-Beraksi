// Reminder function
